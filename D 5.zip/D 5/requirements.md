APScheduler==3.10.1
Django==4.1.5
django_allauth==0.52.0
django_apscheduler==0.6.2
django_filter==22.1
Pillow==9.5.0
python-dotenv==1.0.0